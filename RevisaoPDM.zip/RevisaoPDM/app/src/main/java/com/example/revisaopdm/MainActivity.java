package com.example.revisaopdm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btnSomar, btnSubtrair, btnMultiplicar, btnDividir, btnLimpar;
    private EditText n1, n2;
    private TextView resultado;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSomar = findViewById(R.id.btnSomar);
        btnSubtrair = findViewById(R.id.btnSubtrair);
        btnMultiplicar = findViewById(R.id.btnMultiplicar);
        btnDividir = findViewById(R.id.btnDividir);
        btnLimpar = findViewById(R.id.btnLimpar);

        n1 = findViewById(R.id.n1);
        n2 = findViewById(R.id.n2);
        resultado = findViewById(R.id.resultado);
    }

    public static boolean validaString(String placa){
        boolean valido = false;
        if(placa.matches("[0-9]*")){
            valido = true;
        }
        return valido;
    }

    public void Somar(View view){
        String A = n1.getText().toString().trim();
        String B = n2.getText().toString().trim();

        if (validaString(A) && validaString(B)){
            Double C = Double.parseDouble(A);
            Double D = Double.parseDouble(B);

            Double E = C + D;

            resultado.setText(E.toString());
        } else{
            resultado.setText("Por favor, revise os campos.");
        }
    }

    public void Subtrair(View view){
        String A = n1.getText().toString().trim();
        String B = n2.getText().toString().trim();

        if (validaString(A) && validaString(B)){
            Double C = Double.parseDouble(A);
            Double D = Double.parseDouble(B);

            Double E = C - D;

            resultado.setText(E.toString());
        } else{
            resultado.setText("Por favor, revise os campos.");
        }
    }

    public void Multiplicar(View view){
        String A = n1.getText().toString().trim();
        String B = n2.getText().toString().trim();

        if (validaString(A) && validaString(B)){
            Double C = Double.parseDouble(A);
            Double D = Double.parseDouble(B);

            Double E = C * D;

            resultado.setText(E.toString());
        } else{
            resultado.setText("Por favor, revise os campos.");
        }
    }

    public void Dividir(View view){
        String A = n1.getText().toString().trim();
        String B = n2.getText().toString().trim();

        if (validaString(A) && validaString(B)){
            Double C = Double.parseDouble(A);
            Double D = Double.parseDouble(B);

            Double E = C / D;

            resultado.setText(E.toString());
        } else{
            resultado.setText("Por favor, revise os campos.");
        }
    }

    public void Limpar(View view){
        n1.setText("");
        n2.setText("");
        resultado.setText("");
    }
}